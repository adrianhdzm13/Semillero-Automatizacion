package semilleros;

import org.junit.runner.JUnitCore;

public class Ejecutable {

	public static void main(String[] args) {
		JUnitCore.main("semilleros.runPrueba");

	}

}
